import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Task {
    private static int taskNumberCounter = 0;

    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    public Task(String taskName, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumberCounter++;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID();
        this.taskStatus = taskStatus;
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String initials = taskName.substring(0, 2).toUpperCase();
        String lastName = developerDetails.substring(developerDetails.lastIndexOf(" ") + 1).toUpperCase();
        return initials + ":" + taskNumber + ":" + lastName;
    }

    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
                "Developer Details: " + developerDetails + "\n" +
                "Task Number: " + taskNumber + "\n" +
                "Task Name: " + taskName + "\n" +
                "Task Description: " + taskDescription + "\n" +
                "Task ID: " + taskID + "\n" +
                "Task Duration: " + taskDuration + "hrs";
    }

    public static int returnTotalHours(List<Task> tasks) {
        int totalHours = 0;
        for (Task task : tasks) {
            totalHours += task.taskDuration;
        }
        return totalHours;
    }

    public static void main(String[] args) {
        boolean loggedIn = performLogin();
        if (loggedIn) {
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
            displayMenu();
        }
    }

    private static boolean performLogin() {
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");
        // Perform login logic here
        return true; // Replace with your actual login logic
    }

    private static void displayMenu() {
        int choice;
        List<Task> tasks = new ArrayList<>();

        do {
            String input = JOptionPane.showInputDialog("Menu:\n" +
                    "1) Add tasks\n" +
                    "2) Show report\n" +
                    "3) Quit");
            choice = Integer.parseInt(input);

            switch (choice) {
                case 1:
                    int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks:"));
                    for (int i = 0; i < numTasks; i++) {
                        String taskName = JOptionPane.showInputDialog("Enter task name:");
                        String taskDescription;
                        do {
                            taskDescription = JOptionPane.showInputDialog("Enter task description:");
                            if (taskDescription.length() > 50) {
                                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                            }
                        } while (taskDescription.length() > 50);

                        String developerDetails = JOptionPane.showInputDialog("Enter developer details:");
                        int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration (in hours):"));
                        String taskStatus = JOptionPane.showInputDialog("Enter task status (To Do, Doing, Done):");

                        Task task = new Task(taskName, taskDescription, developerDetails, taskDuration, taskStatus);
                        tasks.add(task);

                        if (task.checkTaskDescription()) {
                            JOptionPane.showMessageDialog(null, "Task successfully captured");
                        } else {
                            JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                        }
                    }
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Showing report...");
                    showReport(tasks);
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Exiting the application");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please enter a valid option.");
                    break;
            }
        } while (choice != 3);
    }

    private static void showReport(List<Task> tasks) {
        StringBuilder report = new StringBuilder();
        for (Task task : tasks) {
            report.append(task.printTaskDetails()).append("\n\n");
        }
        int totalHours = returnTotalHours(tasks);
        report.append("Total hours: ").append(totalHours).append("hrs");

        JOptionPane.showMessageDialog(null, report.toString());
    }

 public static String[] populateDevelopers(List<Task> tasks) {
        String[] developers = new String[tasks.size()];
        for (int i = 0; i < tasks.size(); i++) {
            developers[i] = tasks.get(i).developerDetails;
        }
        return developers;
    }

    public static String[] populateTaskNames(List<Task> tasks) {
        String[] taskNames = new String[tasks.size()];
        for (int i = 0; i < tasks.size(); i++) {
            taskNames[i] = tasks.get(i).taskName;
        }
        return taskNames;
    }

    public static String[] populateTaskIDs(List<Task> tasks) {
        String[] taskIDs = new String[tasks.size()];
        for (int i = 0; i < tasks.size(); i++) {
            taskIDs[i] = tasks.get(i).taskID;
        }
        return taskIDs;
    }

    public static int[] populateTaskDurations(List<Task> tasks) {
        int[] taskDurations = new int[tasks.size()];
        for (int i = 0; i < tasks.size(); i++) {
            taskDurations[i] = tasks.get(i).taskDuration;
        }
        return taskDurations;
    }

    public static String[] populateTaskStatuses(List<Task> tasks) {
        String[] taskStatuses = new String[tasks.size()];
        for (int i = 0; i < tasks.size(); i++) {
            taskStatuses[i] = tasks.get(i).taskStatus;
        }
        return taskStatuses;
    }

    public static void displayTasksWithStatus(List<Task> tasks, String status) {
        StringBuilder output = new StringBuilder();
        for (Task task : tasks) {
            if (task.taskStatus.equalsIgnoreCase(status)) {
                output.append(task.taskName).append(" - Developer: ").append(task.developerDetails)
                        .append(", Duration: ").append(task.taskDuration).append("hrs").append("\n");
            }
        }
        if (output.length() > 0) {
            JOptionPane.showMessageDialog(null, "Tasks with status '" + status + "':\n\n" + output.toString());
        } else {
            JOptionPane.showMessageDialog(null, "No tasks with status '" + status + "'.");
        }
    }

    public static void displayLongestDurationTask(String[] developers, int[] taskDurations) {
        int longestDuration = 0;
        int index = -1;
        for (int i = 0; i < taskDurations.length; i++) {
            if (taskDurations[i] > longestDuration) {
                longestDuration = taskDurations[i];
                index = i;
            }
        }
        if (index != -1) {
            JOptionPane.showMessageDialog(null, "Developer: " + developers[index] +
                    ", Duration: " + longestDuration + "hrs");
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found.");
        }
    }

    public static void searchTaskByName(String[] taskNames, String[] developers, String[] taskStatuses, String searchName) {
        boolean found = false;
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equalsIgnoreCase(searchName)) {
                JOptionPane.showMessageDialog(null, "Task Name: " + taskNames[i] +
                        ", Developer: " + developers[i] + ", Status: " + taskStatuses[i]);
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No tasks found with the name '" + searchName + "'.");
        }
    }

    public static void searchTasksByDeveloper(String[] taskNames, String[] taskStatuses, String[] developers, String searchDeveloper) {
        boolean found = false;
        for (int i = 0; i < developers.length; i++) {
            if (developers[i].equalsIgnoreCase(searchDeveloper)) {
                JOptionPane.showMessageDialog(null, "Task Name: " + taskNames[i] +
                        ", Status: " + taskStatuses[i]);
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No tasks found assigned to developer '" + searchDeveloper + "'.");
        }
    }

    public static void deleteTaskByName(List<Task> tasks, String deleteTaskName) {
        boolean found = false;
        for (int i = 0; i < tasks.size(); i++) {
            if (tasks.get(i).taskName.equalsIgnoreCase(deleteTaskName)) {
                tasks.remove(i);
                found = true;
                break;
            }
        }
        if (found) {
            JOptionPane.showMessageDialog(null, "Task '" + deleteTaskName + "' successfully deleted.");
        } else {
            JOptionPane.showMessageDialog(null, "No tasks found with the name '" + deleteTaskName + "'.");
        }
   
import java.util.Scanner;
import java.util.regex.Pattern;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.accountcreation;

/**
 *
 * @author My PC
 */
public class AccountCreation {
    // Define a class to hold the account information
    private static class Account {
        String username;
        String password;
        String firstName;
        String lastName;

        public Account(String username, String password, String firstName, String lastName) {
            this.username = username;
            this.password = password;
            this.firstName = firstName;
            this.lastName = lastName;
        }
    }

    // Define an array to hold the created accounts
    private static Account[] accounts = new Account[10];
    private static int numAccounts = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create some sample accounts for testing purposes
        accounts[0] = new Account("user1", "Password1!", "John", "Doe");
        accounts[1] = new Account("user2", "Password2@", "Jane", "Doe");
        numAccounts = 2;

        // Prompt the user to choose an action
        System.out.println("Welcome to the account system. Please choose an action:");
        System.out.println("1. Create an account");
        System.out.println("2. Login");

        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (choice == 1) {
            // Create a new account
            createAccount(scanner);
        } else if (choice == 2) {
            // Prompt the user to enter their login details
            System.out.println("Enter your username:");
            String username = scanner.nextLine();
            System.out.println("Enter your password:");
            String password = scanner.nextLine();

            // Validate the login details
            for (int i = 0; i < numAccounts; i++) {
                Account account = accounts[i];
                if (account.username.equals(username) && account.password.equals(password)) {
                    System.out.println("Welcome " + account.firstName + " " + account.lastName + ", it is great to see you again.");
                    return;
                }
            }
            System.out.println("Username or password incorrect, please try again");
        } else {
            System.out.println("Invalid choice");
        }
    }

    private static void createAccount(Scanner scanner) {
        // Prompt the user to enter their account details
        System.out.println("Enter your username:");
        String username = scanner.nextLine();
        System.out.println("Enter your password:");
        String password = scanner.nextLine();
        System.out.println("Enter your first name:");
        String firstName = scanner.nextLine();
        System.out.println("Enter your last name:");
        String lastName = scanner.nextLine();

        // Validate the username format
        if (!Pattern.matches("[a-zA-Z0-9_]{1,5}", username)) {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return;
        }

        // Validate the password complexity
        if (password.length() < 8 || !Pattern.matches(".*[A-Z].*", password) || !Pattern.matches(".*\\d.*", password) || !Pattern.matches(".*[!@#$%^&*()].*", password)) {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            return;
        }

        // Create the account and add it to the array
        Account account = new Account(username, password, firstName, lastName);
        accounts[numAccounts] = account;
        numAccounts
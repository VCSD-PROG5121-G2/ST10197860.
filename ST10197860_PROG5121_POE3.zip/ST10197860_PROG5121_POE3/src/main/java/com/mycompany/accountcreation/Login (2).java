
package com.mycompany.accountcreation;

public class Login {
    
    public boolean checkUserName(String userName) {
        // Ensures that any username contains an under score (_) and is no more than 5 characters long
        if (userName.contains("_") && userName.length() <= 5) {
            return true;
        }
        return false;
    }
    
    public boolean checkPasswordComplexity(String password) {
        // Ensures that passwords meet the password complexity rules
        // The password must be:
        // - At least eight characters long
        // - Contain a capital letter
        // - Contain a number
        // - Contain a special character
        String passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        return password.matches(passwordPattern);
    }
    
    public String registerUser(String userName, String password) {
        // Returns the necessary registration messaging indicating if:
        // - The username is incorrectly formatted
        // - The password does not meet the complexity requirements
        // - The two above conditions have been met and the user has been registered successfully
        if (!checkUserName(userName)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        else if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        else {
            // User is registered successfully
            // Replace <user first name> and <user last name> with actual user data
            return "Welcome <user first name>, <user last name>. It is great to see you.";
        }
    }
    
    public boolean loginUser(String userName, String password) {
        // Verifies that the login details entered matches the login details stored when the user registers
        // Replace with actual login verification code
        return false;
    }
    
    public String returnLoginStatus(boolean isLoginSuccessful) {
        // Returns the necessary messaging for a successful or failed login
        if (isLoginSuccessful) {
            return "Login successful.";
        }
        else {
            return "Login failed.";
        }
    }
   }

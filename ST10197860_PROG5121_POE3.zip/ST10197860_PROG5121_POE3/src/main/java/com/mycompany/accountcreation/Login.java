import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

package com.mycompany.accountcreation;

public class Login {
    
    public boolean checkUserName(String userName) {
        // Ensures that any username contains an under score (_) and is no more than 5 characters long
        if (userName.contains("_") && userName.length() <= 5) {
            return true;
        }
        return false;
    }
    
    public boolean checkPasswordComplexity(String password) {
        // Ensures that passwords meet the password complexity rules

        String passwordPattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        return password.matches(passwordPattern);
    }
    
    public String registerUser(String userName, String password) {
        // Returns the necessary registration messaging indicating if:
        // The username is incorrectly formatted
        // The password does not meet the complexity requirements
        // The two above conditions have been met and the user has been registered successfully
        if (!checkUserName(userName)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        else if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        else {
            // User is registered successfully
            // Replace <user first name> and <user last name> with actual user data
            return "Welcome <user first name>, <user last name>. It is great to see you.";
        }
    }
    
    public boolean loginUser(String userName, String password) {
        // Verifies that the login details entered matches the login details stored when the user registers
        // Replace with actual login verification code
        return false;
    }
    
    public String returnLoginStatus(boolean isLoginSuccessful) {
        // Returns the necessary messaging for a successful or failed login
        if (isLoginSuccessful) {
            return "Login successful.";
        }
        else {
            return "Login failed.";
        
    
   

       boolean loggedIn = performLogin();
        if (loggedIn) {
            JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");
            displayMenu();
        }
    }

    private static boolean performLogin() {
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");
        // Perform login logic here
        return true; // Replace with your actual login logic
    }

    private static void displayMenu() {
        int choice;

        do {
            String input = JOptionPane.showInputDialog("Menu:\n" +
                    "1) Add tasks\n" +
                    "2) Show report\n" +
                    "3) Quit");
            choice = Integer.parseInt(input);

            switch (choice) {
                case 1:
                    Task.main(args); // Call the main method of the Task class
                    break;
                case 2:
                    JOptionPane.showMessageDialog(null, "Coming Soon");
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Exiting the application");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please enter a valid option.");
                    break;
            }
        } while (choice != 3);
    }
}





public class LoginTest {
    
    Login login = new Login();
    
    @Test
    public void testCheckUserName_correctlyFormatted() {
        // Test that a correctly formatted username returns true
        assertTrue(login.checkUserName("kyl_1"));
    }
    
    @Test
    public void testCheckUserName_incorrectlyFormatted() {
        // Test that an incorrectly formatted username returns false
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }
    
    @Test
    public void testCheckPasswordComplexity_meetsRequirements() {
        // Test that a password meeting the complexity requirements returns true
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }
    
    @Test
    public void testCheckPasswordComplexity_doesNotMeetRequirements() {
        // Test that a password not meeting the complexity requirements returns false
        assertFalse(login.checkPasswordComplexity("password"));
    }
    
    @Test
    public void testRegisterUser_usernameIncorrectlyFormatted() {
        // Test that a user with an incorrectly formatted username gets an error message
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is

 
    
                
        
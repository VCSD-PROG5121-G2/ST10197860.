
        
package com.mycompany.accountcreation;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author My PC
 */
//could not get Junit jar file to install will try to fix by next submission/
 public class LoginTest {
    
    Login login = new Login();
    
    @Test
    public void testCheckUserName_correctlyFormatted() {
        // Test that a correctly formatted username returns true
        assertTrue(login.checkUserName("kyl_1"));
    }
    
    @Test
    public void testCheckUserName_incorrectlyFormatted() {
        // Test that an incorrectly formatted username returns false
        assertFalse(login.checkUserName("kyle!!!!!!!"));
    }
    
    @Test
    public void testCheckPasswordComplexity_meetsRequirements() {
        // Test that a password meeting the complexity requirements returns true
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }
    
    @Test
    public void testCheckPasswordComplexity_doesNotMeetRequirements() {
        // Test that a password not meeting the complexity requirements returns false
        assertFalse(login.checkPasswordComplexity("password"));
    }
    
    @Test
    public void testRegisterUser_usernameIncorrectlyFormatted() {
        // Test that a user with an incorrectly formatted username gets an error message
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is
    
}
